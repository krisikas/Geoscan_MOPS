import importlib

from .Metashape import *

# copy private variables
globals().update(importlib.import_module('Metashape.Metashape').__dict__)
